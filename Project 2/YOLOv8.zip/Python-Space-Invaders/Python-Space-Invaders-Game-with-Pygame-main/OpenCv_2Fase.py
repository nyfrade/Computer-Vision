import time
import cv2
import os
import numpy as np
from ultralytics import YOLO
import torch

isMovingLeft = False
isMovingRight = False
isShooting = False

#Coordenadas do centro de massa do objeto, quando não há objeto são definidos como -100
cXCopy = -100
cYCopy = -100

#use_cam = False
# folder ="Files"
# file = "vtest.avi"

model = YOLO("yolov8n.pt")
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)

print("Known Classes ({})".format(len(model.names)))
for i in range(len(model.names)):
    print(model.names[i])

before = 0

def cap_main2():
    # global use_cam, folder, file
    #
    # if use_cam:
    #     cap = cv2.VideoCapture(0)
    # else:
    #     cap = cv2.VideoCapture(os.path.join(folder, file))
    cap = cv2.VideoCapture(0)

    return cap

#device = torch.device("cuda:0" if
#model.to(device) -> faz explicitamente no gpu (Criar ambiente em python 3.10 e instalar o pip install de pytorch e fazer trabalhar nesse ambiente)

def open_cv_loop2(cap):

    ret, frame = cap.read()
    global cXCopy, cYCopy
    global isMovingRight, isMovingLeft, isShooting
    global before

    model_detected = "cell phone"

    if ret == True:
        now = time.time()
        fps = 1/ (now - before)
        before = now

        h, w, c = frame.shape

        #if use_cam:
        frame_mirror = frame[:, ::-1, :]
        # else:
        #     frame_mirror = frame

        objects = model.predict(frame_mirror, verbose=False)
        objects = objects[0]

        image_objects = frame_mirror.copy()

        # calcular a área dos objetos para assim só apresentar a grid do maior deles na tela
        maior_area = 0
        maior_objeto = None

        for object in objects:
            (x1, y1, x2, y2, conf, class_id) = object.boxes.data[0]

            if conf > 0.5 and model.names[int(class_id)] == model_detected: # ou 'cell phone'

                # calcular base e altura de cada retângulo
                base = abs(x2 - x1)  # usar abs para evitar problemas com números negativos
                altura = abs(y2 - y1)
                area = base * altura

                # comparar as diferentes áreas com a maior área até o momento
                # e os parâmetros que precisamos do maior objeto
                if area > maior_area:
                    maior_area = area
                    maior_objeto = (x1, y1, x2, y2, conf, class_id)

        # mostrar só a grid do maior objeto
        if maior_objeto is not None:
            (x1, y1, x2, y2, conf, class_id) = maior_objeto

            p1 = (int(x1), int(y1))
            p2 = (int(x2), int(y2))

            cv2.rectangle(img=image_objects,
                          pt1=p1,
                          pt2=p2,
                          color=(0, 255, 0),
                          thickness=2)
            object_text = "{}:{:.2f}".format(model.names[int(class_id)], conf)


            cv2.putText(img=image_objects,
                        text=object_text,
                        org=(int(x1), int(y1)),
                        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                        fontScale=0.5,
                        color=(0, 255, 0),
                        thickness=2)

            # Calcular o centro do retângulo
            # usar fórmula para calcular as coordenadas do centro do retângulo: centro=((x1+x2)/2,(y1 + y2)/2))
            center_objectX = int((x1 + x2) / 2)
            center_objectY = int((y1 + y2) / 2)

            cXCopy = center_objectX
            cYCopy = center_objectY

            # Desenhar um círculo no centro de massa do objeto
            cv2.circle(img=image_objects,
                       center=(center_objectX, center_objectY),
                       radius=5,
                       color=(0, 0, 255),
                       thickness=-1)

        text_to_show = "{} fps".format(np.round(fps))
        cv2.putText(img=image_objects,
                    text=text_to_show,
                    org=(10, 30),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=1,
                    color=(0, 255, 0),
                    thickness=2)

        text_object_detected = "Objeto a detetar: {}".format(model_detected)
        cv2.putText(img=image_objects,
                    text= text_object_detected,
                    org=(10,450),
                    fontFace=cv2.FONT_HERSHEY_SIMPLEX,
                    fontScale=0.5,
                    color=(255, 255, 255),
                    thickness=2)


        # ------movimento com base na posição do objeto na câmara
        # controlo do jogo com as coordenadas do centro do objeto e o size da tela do jogo
        frame_width = frame_mirror.shape[1]  # número de colunas (largura)
        frame_height = frame_mirror.shape[0]  # número de linhas (altura)

        # Limite horizontal para deslocar para a esquerda/direita
        # definir uma zona neutra para que quando o objeto está no meio, a nave não se move
        # a nave só se vai mover se o objeto estiver claramente à esquerda ou à direita
        center_zone = frame_width // 3  # zona central ou zona morta onde não se fara nada

        # inicializar as variáveis de controlo
        # mover para a esquerda/direita segundo a posição horizontal (cXCopy)
        isMovingLeft = False
        isMovingRight = False
        # disparar quando o objeto sobe (o cYCopy diminui)
        isShooting = False

        # verificar se há um objeto a ser detetado e em que parte da tela se encontra
        if cXCopy != -100:
            # Mover para a esquerda se o centro do objeto (cXCopy) está à esquerda da zona central
            # ativar o movimento à esquerda
            if cXCopy < frame_width // 2 - center_zone // 2:
                cv2.putText(image_objects, "Esquerda", (100, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                isMovingLeft = True
            # Mover para a direita se o centro do objeto (cXCopy) está à direita da zona central
            elif cXCopy > frame_width // 2 + center_zone // 2:
                cv2.putText(image_objects, "Direita", (400, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                isMovingRight = True

            # Disparo quando o objeto vai para cima (menor Y → mais alto)
            # se o objeto estiver no centro superior da imagem ativa o disparo
            if cYCopy < frame_height // 3:
                cv2.putText(image_objects, "Cima", (250, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                isShooting = True

        cv2.imshow("objects", image_objects)

    else:
        return None, False, False, False

    return frame, isMovingLeft, isMovingRight, isShooting

def cap_release2(cap):
    # FAZ RELEASE DO CAP E FECHA A JANELA EM QUESTÃO
    if cap.isOpened():
        cap.release()
        cv2.destroyWindow("objects")