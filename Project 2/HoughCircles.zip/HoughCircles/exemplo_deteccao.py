import cv2 as cv2
import numpy as np

# Assumindo que 'blurred_frame' é a imagem em escala de cinzentos e suavizada.

# Deteta círculos na imagem usando a Transformada de Hough para Círculos.
# dp=1.2: Resolução do acumulador. Um valor > 1 reduz a resolução para ganhar performance.
# minDist=100: Distância mínima entre os centros de círculos detetados.
# param1=100: Limiar superior para o detetor de arestas Canny interno.
# param2=50: Limiar do acumulador. Define o número mínimo de "votos" para que um círculo seja considerado válido.
# minRadius=75, maxRadius=400: Restringe a procura a círculos dentro deste intervalo de raios.
circles = cv2.HoughCircles(blurred_frame, cv2.HOUGH_GRADIENT, dp=1.2, minDist=100,
                           param1=100, param2=50, minRadius=75, maxRadius=400)

if circles is not None:
    # Converte as coordenadas e o raio para inteiros de 16 bits sem sinal.
    circles = np.uint16(np.around(circles))
    
    # Itera sobre os círculos detetados para os desenhar.
    for i in circles[0, :]:
        # Desenha a circunferência do círculo
        cv2.circle(frame, (i[0], i[1]), i[2], (255, 0, 255), 3)
        # Desenha o centro do círculo
        cv2.circle(frame, (i[0], i[1]), 1, (0, 100, 100), 3)
