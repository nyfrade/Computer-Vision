import numpy as np

# 'prevCircle' armazena as coordenadas (x, y, r) do círculo rastreado no frame anterior.
# 'circles' é um array NumPy com os círculos detetados no frame atual.

# Função para calcular a distância euclidiana ao quadrado.
# Evita o cálculo da raiz quadrada, que é computacionalmente dispendioso,
# uma vez que apenas precisamos de comparar distâncias.
dist = lambda x1, y1, x2, y2: (np.int32(x2) - np.int32(x1)) ** 2 + (np.int32(y2) - np.int32(y1)) ** 2

chosen_circle = None

if circles is not None:
    circles = np.uint16(np.around(circles))

    if prevCircle is not None:
        # Se já existe um círculo rastreado, encontra o círculo no frame atual
        # que está mais próximo do círculo anterior.
        # A função 'min' com uma expressão lambda é usada para encontrar o círculo
        # com a distância mínima de forma eficiente.
        chosen = min(circles[0, :], key=lambda c: dist(c[0], c[1], prevCircle[0], prevCircle[1]))
    else:
        # Se este é o primeiro frame com círculos detetados,
        # seleciona o primeiro círculo da lista como o círculo de interesse.
        chosen = circles[0, 0]

    chosen_circle = chosen
    
    # Atualiza o 'prevCircle' com o círculo escolhido para o próximo frame.
    prevCircle = chosen
