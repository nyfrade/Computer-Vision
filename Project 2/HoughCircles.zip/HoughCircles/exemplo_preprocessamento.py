import cv2 as cv2
import numpy as np

# Assumindo que 'videoCapture' é um objeto cv2.VideoCapture inicializado
# e 'frame' é a imagem capturada.

# videoCapture.read() devolve o frame
ret, frame = videoCapture.read()

# Espelhamento horizontal para uma experiência mais intuitiva
frame = cv2.flip(frame, 1)

# Conversão para escala de cinzentos para reduzir a carga computacional
grayframe = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

# Aplicação de um filtro gaussiano para suavizar o ruído.
# O Kernel de (17, 17) foi escolhido experimentalmente para obter o melhor 
# equilíbrio entre a supressão de ruído e a preservação das bordas do círculo.
# O sigmaX=0 indica ao OpenCV para o calcular automaticamente com base no tamanho do kernel.
blurred_frame = cv2.GaussianBlur(grayframe, (17, 17), 0) 


