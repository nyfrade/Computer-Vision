import cv2 as cv2
import numpy as np
import time

#diferenças com o do setor
#rackbars para ajustar parâmetros em tempo real este  tem valores fixos
#o setor usa canny + houghCircles, este faz só gaussianblur + houghCircles
#o do setor, a deteção depende do resultado do canny nesteu depende do blur + intensidade do gradiente
#este implementa tracking do círculo mais próximo com distância euclidiana; o do setor b faz tracking
# este n tem callbacks
# o do setor desenha círculos sobre uma cópia da imagem original este  desenha direto no frame

prevCircle = None
# função para calcular a distância euclidiana ao quadrado ( soma dos quadrados das diferenças entre as coordenadas)
# usar np.int32 para evitar overflow com coordenadas uint16 só a fazer int ou nada crasha com overflow
dist = lambda x1, y1, x2, y2: (np.int32(x2) - np.int32(x1)) ** 2 + (np.int32(y2) - np.int32(y1)) ** 2

# var para o  cálculo do FPS
start_time = time.time()
frame_count = 0
fps = 0

def cap_main():
    videoCapture = cv2.VideoCapture(0)
    cv2.namedWindow('detected circles')
    return videoCapture

def open_cv_loop(videoCapture):
    global prevCircle, start_time, frame_count, fps

    ret, frame = videoCapture.read()
    if not ret:
        return None, False, False, False, None

    # calculo ee mostrarr fps
    frame_count += 1
    elapsed_time = time.time() - start_time
    if elapsed_time > 1.0:
        fps = frame_count / elapsed_time
        frame_count = 0
        start_time = time.time()

    frame = cv2.flip(frame, 1)
    grayframe = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred_frame = cv2.GaussianBlur(grayframe, (17, 17), 0) # sigmaX=0 é para q o open cv n calcule automatico

    # ajustar conforme nec
    circles = cv2.HoughCircles(blurred_frame, cv2.HOUGH_GRADIENT, dp=1.2, minDist=100,
                               param1=100, param2=50, minRadius=75, maxRadius=400)

    isMovingLeft = False
    isMovingRight = False
    isShooting = False
    chosen_circle = None

    if circles is not None:
        # arredonda as coordenadas e o raio para o inteiro mais próximo
        circles = np.uint16(np.around(circles))


        if prevCircle is not None:
            # Se temos um círculo anterior, encontramos o círculo atual mais próximo dele.
            # `min` com uma chave lambda é uma forma eficiente de encontrar o mínimo em uma coleção.
            chosen = min(circles[0, :], key=lambda c: dist(c[0], c[1], prevCircle[0], prevCircle[1]))
        else:
            # se é o primeiro círculo detectado, usamos o primeiro da lista
            chosen = circles[0, 0]

        chosen_circle = chosen

        # cod para desenhar o circulo
        x, y, r = chosen[0], chosen[1], chosen[2]
        cv2.circle(frame, (x, y), 1, (0, 100, 100), 3)  # desenha o centro
        cv2.circle(frame, (x, y), r, (255, 0, 255), 3) # desenha a borda
        prevCircle = chosen # atualiza o círculo anterior para o próximo frame

        frame_width = frame.shape[1]
        frame_height = frame.shape[0]
        center_zone_width = frame_width // 3

        if x < frame_width // 2 - center_zone_width // 2:
            isMovingLeft = True
        elif x > frame_width // 2 + center_zone_width // 2:
            isMovingRight = True

        if y < frame_height // 3:
            isShooting = True

    # fps no frame
    cv2.putText(frame, f"FPS: {fps:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow('detected circles', frame)
    cv2.waitKey(1)

    return frame, isMovingLeft, isMovingRight, isShooting, chosen_circle

def cap_release(videoCapture):
    videoCapture.release()
    cv2.destroyAllWindows()